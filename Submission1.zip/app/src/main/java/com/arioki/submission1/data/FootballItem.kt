package com.arioki.submission1.data

data class FootballItem(
    val id:String?,
    val name:String?,
    val badge: Int,
    val description:String?

)